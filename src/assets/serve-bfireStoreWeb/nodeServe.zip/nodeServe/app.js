var express = require('express');
var app = express();
var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: false
}));

app.all('*', function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Content-Type,Content-Length, Authorization, Accept,X-Requested-With");
  res.header("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS");
  res.header("X-Powered-By", ' 3.2.1')
  if (req.method == "OPTIONS") res.send(200);
  else next();
});

app.get('/', function (req, res) {
  res.send('首页');
})
// 获取文件集合
app.post('/getFolderInfo', function (req, res) {
  try {
    var fs = require('fs');
    var path = require('path');
    var filePath = path.resolve(req.body.folderUrl);
    var jsonFolder = '';

    function getAllDirs(mypath = filePath) {
      const items = fs.readdirSync(mypath);
      let result = [];
      // 遍历当前目录中所有的文件和文件夹
      items.map(item => {
        let temp = path.join(mypath, item);
        // 若当前的为文件夹
        if (fs.statSync(temp).isFile()) {
          var url = mypath + '\\' + item;
          var stateInfo = fs.statSync(url);
          var fileSizes = stateInfo.size / 1048576;
          fileSizes = fileSizes.toFixed(2);
          fileSizes += 'M';
          result.push(item); // 存储当前文件夹的名字
          result.push(fileSizes);
          jsonFolder += "{";
          jsonFolder += '"fileName":"' + item + '",';
          jsonFolder += '"fileSizes": "' + fileSizes + '"';
          jsonFolder += '}';
          jsonFolder += ',';
        }
      });
      return result;
    }
    jsonFolder += "[";
    getAllDirs(filePath);
    jsonFolder = jsonFolder.substr(0, jsonFolder.length - 1);
    jsonFolder += "]";
    var jsonsFolders = JSON.parse(jsonFolder);
    res.json(jsonsFolders);
  } catch (e) {
    console.log(e);
  }
})
// 获取文件夹集合
app.get('/getJsonFolder', function (req, res) {
  try {
    var fs = require('fs');
    var path = require('path');
    var filePath = path.resolve('D:\\ava_Code\\1\\bfireStoreWeb\\src\\assets\\ProductUseInstructions');

    function getAllDirs(mypath) {
      const items = fs.readdirSync(mypath);
      // 遍历当前目录中所有的文件和文件夹
      items.map(item => {
        let temp = path.join(mypath, item);
        // 若当前的为文件夹
        if (fs.statSync(temp).isDirectory()) {
          var url = mypath + '\\' + item;
          getHtmlTexts(url);
        }
      });
    }
    var jsonFolder = '';
    // 读取文件夹名称
    function getHtmlTexts(arr) {
      let constUrl = arr;
      let cruxName = arr;
      let arrs = cruxName.split('\\');
      let fileUrl = '';
      for (let i = 0; i < arrs.length; i++) {
        fileUrl += arrs[i];
        fileUrl += '**';
      }
      let arrsum = arrs.length - 1;
      let fileName = arrs[arrsum];
      if (fs.statSync(arr).isDirectory()) {
        jsonFolder += "{";
        jsonFolder += '"folderName":"' + fileName + '",';
        jsonFolder += '"folderUrl": "' + fileUrl + '"';
        jsonFolder += '}';
        jsonFolder += ',';
        getAllDirs(constUrl);
      }
    }
    jsonFolder += "[";
    getHtmlTexts(filePath);
    jsonFolder = jsonFolder.substr(0, jsonFolder.length - 1);
    jsonFolder += "]";
    var jsonsFodler = JSON.parse(jsonFolder);
    res.json(jsonsFodler);
  } catch (e) {
    console.log(e);
  }

})

app.listen(3000, '127.0.0.1');